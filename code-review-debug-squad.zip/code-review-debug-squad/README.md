# Code Review & Debug Squad

A Streamlit-based code assistant that reviews a submitted code snippet using a team-of-agents workflow.

## Features
- Interactive GUI to paste code and choose a task
- Bug-finding, style review, code-fix suggestions, and test-case generation
- LangChain prompt template and LCEL chain
- Groq-hosted LLM integration
- Task selection for basic intent routing

## Agent roles
1. **Bug-Finder Agent** — identifies logical errors, edge cases, and runtime risks.
2. **Style/Lint Agent** — checks readability, naming, and language conventions.
3. **Fixer Agent** — proposes corrected code.
4. **Test-Writer Agent** — suggests test cases and expected results.

## Tech stack
Python, Streamlit, LangChain, Groq API.

## Run locally
1. Install Python 3.10 or later.
2. Create and activate a virtual environment.
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Set your Groq API key as an environment variable named `GROQ_API_KEY`.
   - Windows PowerShell:
     ```powershell
     $env:GROQ_API_KEY="your_key_here"
     ```
   - macOS/Linux:
     ```bash
     export GROQ_API_KEY="your_key_here"
     ```
5. Start the app:
   ```bash
   streamlit run app.py
   ```

## Note
This is a starter implementation. The current version uses an LLM-powered specialist workflow and simple task-based routing. A production/assignment-complete version should add a ChromaDB knowledge base, retrieval-based routing, isolated code execution, and automated test execution. Never run untrusted submitted code directly on your machine.
