import os
import streamlit as st
from langchain_groq import ChatGroq
from langchain_core.prompts import ChatPromptTemplate

st.set_page_config(page_title="Code Review & Debug Squad", page_icon="🛠️")
st.title("🛠️ Code Review & Debug Squad")
st.caption("A multi-agent-inspired assistant for reviewing, fixing, and testing code.")

code = st.text_area("Paste your code", height=260, placeholder="def add(a, b):\n    return a - b")
task = st.selectbox("Choose a task", ["Full code review", "Find bugs", "Improve code style", "Explain code", "Generate test cases"])

if st.button("Run review", type="primary"):
    if not code.strip():
        st.warning("Please paste some code first.")
    elif not os.getenv("GROQ_API_KEY"):
        st.error("Set your GROQ_API_KEY environment variable, then restart the app.")
    else:
        prompt = ChatPromptTemplate.from_messages([
            ("system", """You are Code Review & Debug Squad. Work as four specialist agents:
1. Bug-Finder: identify logical errors, edge cases, and runtime risks.
2. Style/Lint: review readability, naming, and language conventions.
3. Fixer: provide corrected code when appropriate.
4. Test-Writer: suggest tests and expected results.
Be accurate. Do not claim code was executed unless it was. Use clear headings."""),
            ("human", "Task: {task}\n\nCode:\n```text\n{code}\n```\n\nReturn a concise, structured review.")
        ])
        with st.spinner("The review squad is analysing your code..."):
            try:
                model = ChatGroq(model="llama-3.3-70b-versatile", temperature=0)
                result = (prompt | model).invoke({"task": task, "code": code})
                st.markdown(result.content)
            except Exception as e:
                st.error(f"Request failed: {e}")

with st.expander("How the agents work"):
    st.markdown("""
    - **Bug-Finder Agent:** detects logical errors and edge cases.
    - **Style/Lint Agent:** checks readability and conventions.
    - **Fixer Agent:** proposes corrected code.
    - **Test-Writer Agent:** creates test cases.

    The selected task acts as a simple intent-routing input.
    """)
